// let text = "Hello World, I am learning JavaScript"
// let names = ["Ali", "Zain", "usman"];

// let heading = document.getElementById("heading");
// let paragraph = document.getElementsByClassName(".para");
// let Name = document.querySelector("#name");
// console.log(paragraph.innerHTML)
// heading.innerText = "I am Learning JavaScript"
// heading.style.backgroundColor = "red"
// console.log(heading.innerText)

// function myFunc() {
//     console.log(Name.value)
// }

//  let num1 = 100;
//  let num2 = "100";

// //  if (num1 > num2) {
// //      document.write(num1)
// //  }
// if (num1 === num2){
//      document.write("Number 1 and Number 2 are equal")
//  }
//  else {
//      document.write("bla bla")
//  }

// for (let t = 0; t <= text.length;  t++) {
//     console.log(text[t])
//     if (t == 10)
//         continue;
// }

// let txt = text.substr(5,10)

// console.log(txt);

// let names = ['Ali', 'Bazil'];

// names[0] = 'Zain'

// console.log(names[0]);

